JANANI DIAGNOSTIC CENTER - DESKTOP SOFTWARE SETUP
=============================================================
Location: Amin Tower, Trunk Road, Feni
Hotline: 01711-307064, 01715-081014

HOW TO RUN THE DESKTOP SOFTWARE:
1. Double-click "Launch-Janani-Desktop.bat" to start the desktop app immediately in native standalone window mode.
2. Or run "Install-Janani-Desktop-Shortcut.ps1" in PowerShell to add an icon to your Windows Desktop.
3. Or in Microsoft Edge / Google Chrome, click the "Install" icon in the address bar to install as a native Desktop App.

FEATURES INCLUDED:
- Clean Medical Typography (Inter + JetBrains Mono)
- Official Logo with DGHS Accreditation & 24/7 Hotline
- Live Active QR Code Public Verification Portal
- 3-Verifier Authorization (2 Medical Technologists + 1 Doctor)
- Dynamic Print Layouts (A4, A5, Letter, Legal, B5, Custom Dimensions)
- Zero Duplicate Phone Numbers or Barcodes
- Offline Data Persistence & Diagnostic Reporting
